var clr = host.lib('mscorlib', 'System', 'System.Core');
var Dictionary = clr.System.Collections.Generic.Dictionary;
var Environment = clr.System.Environment;

// Load Newtonsoft.Json cleanly
var jsonNet = host.lib('Newtonsoft.Json');

// Now alias the major types for easy access
var jsonLinq = jsonNet.Newtonsoft.Json.Linq;
var jsonConvert = jsonNet.JsonConvert;
var jObject = jsonLinq.JObject;
var formatting = jsonNet.Newtonsoft.Json.Formatting;

// Function to format raw JSON
function formatJson(rawJson) {
    var obj = jObject.Parse(rawJson);
    return obj.ToString(formatting.Indented);
}

var xferLang = host.lib('ParksComputing.Xfer.Lang');

var startWorkspace = xk.store.get("startWorkspace");

if (startWorkspace != null) {
    xk.setActiveWorkspace(startWorkspace);
}

function sayHello() {
    console.log("Hello from globalInitScript.js");
    return "";
}
